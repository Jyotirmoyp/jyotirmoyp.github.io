/* research.js: the collaboration globe on the Research page.
   The numbered list in the page (#collab) is the single source of data: each <li> carries
   data-lat / data-lng and a link. Plotly is only downloaded when the map is about to scroll into view. */
(function () {
    var mapEl = document.getElementById('map');
    var listEl = document.getElementById('collab');
    if (!mapEl || !listEl) return;

    var PLOTLY_URL = 'https://cdn.plot.ly/plotly-1.58.5.min.js';
    var TEAL = '#0B6B70', HOT = '#C0442A', INK = '#15222C', RULE = '#CBD5D8';

    var people = [].slice.call(listEl.querySelectorAll('li')).map(function (li) {
        var a = li.querySelector('a');
        return { lat: parseFloat(li.dataset.lat), lng: parseFloat(li.dataset.lng), name: a.textContent.trim().replace(/\s+/g, ' '), url: a.href };
    });
    var home = { lat: parseFloat(mapEl.dataset.lat), lng: parseFloat(mapEl.dataset.lng), name: mapEl.dataset.label };

    function draw() {
        var lines = { type: 'scattergeo', mode: 'lines', lat: [], lon: [], hoverinfo: 'none', name: 'Connections',
                      line: { width: 1, color: 'rgba(11,107,112,0.55)' } };
        people.forEach(function (p) {
            lines.lat.push(home.lat, p.lat, null);
            lines.lon.push(home.lng, p.lng, null);
        });

        var markers = {
            type: 'scattergeo', mode: 'markers+text', name: 'Collaborators',
            lat: people.map(function (p) { return p.lat; }),
            lon: people.map(function (p) { return p.lng; }),
            text: people.map(function (_, i) { return String(i + 1); }),
            textposition: 'top right', textfont: { size: 10, color: INK },
            hovertext: people.map(function (p) { return p.name; }), hoverinfo: 'text',
            marker: { size: 9, color: TEAL, line: { width: 1, color: '#fff' } }
        };

        var office = {
            type: 'scattergeo', mode: 'markers', name: 'My office',
            lat: [home.lat], lon: [home.lng], hovertext: [home.name], hoverinfo: 'text',
            marker: { size: 14, color: HOT, symbol: 'star', line: { width: 1, color: '#fff' } }
        };

        var layout = {
            geo: {
                projection: { type: 'orthographic', rotation: { lon: -30, lat: 30 } },
                showland: true, landcolor: '#F7F9F9',
                showocean: true, oceancolor: '#DCE7EB',
                showlakes: true, lakecolor: '#DCE7EB',
                showcountries: true, countrycolor: RULE,
                coastlinecolor: '#9FB0B6', showrivers: false,
                bgcolor: 'rgba(0,0,0,0)', framecolor: RULE, framewidth: 1
            },
            font: { family: '"Hanken Grotesk", system-ui, sans-serif', color: INK },
            paper_bgcolor: 'rgba(0,0,0,0)',
            hovermode: 'closest', showlegend: false,
            margin: { l: 0, r: 0, t: 0, b: 0 }
        };

        mapEl.textContent = '';
        mapEl.removeAttribute('data-state');
        Plotly.newPlot(mapEl, [lines, markers, office], layout,
                       { responsive: true, displayModeBar: false, scrollZoom: false }).then(function () {
            mapEl.on('plotly_click', function (ev) {
                var pt = ev.points[0];
                if (pt.data.name === 'Collaborators') window.open(people[pt.pointNumber].url, '_blank', 'noopener');
            });
        });
    }

    function load() {
        if (window.Plotly) return draw();
        var s = document.createElement('script');
        s.src = PLOTLY_URL;
        s.onload = draw;
        s.onerror = function () { mapEl.dataset.state = 'error'; mapEl.textContent = 'The map could not be loaded. The collaborators are listed below.'; };
        document.head.appendChild(s);
    }

    mapEl.dataset.state = 'loading';
    mapEl.textContent = 'Loading map…';
    if ('IntersectionObserver' in window) {
        new IntersectionObserver(function (entries, obs) {
            if (entries[0].isIntersecting) { obs.disconnect(); load(); }
        }, { rootMargin: '400px' }).observe(mapEl);
    } else {
        load();
    }
})();
